import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    TextInput,
    Modal,
    Image,
    StatusBar,
    Alert,
    Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useIsFocused } from '@react-navigation/native';
import api, { BASE_URL } from '../../general/api';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Video from 'react-native-video';
import { launchImageLibrary, Asset } from 'react-native-image-picker';

const resolveMediaUrl = (url?: string | null): string => {
    if (!url) return '';
    const storageIdx = url.indexOf('/storage/');
    if (storageIdx !== -1) {
        return `${BASE_URL}${url.substring(storageIdx)}`;
    }
    if (url.startsWith('/')) {
        return `${BASE_URL}${url}`;
    }
    return url;
};

type Media = {
    id_media: number;
    id_bai_dang: number;
    loai_media: 'image' | 'video';
    media_url: string;
    thu_tu: number;
};

type BaiDang = {
    id_bai_dang: number;
    id_nguoi_dung: number;
    caption: string;
    pham_vi_hien_thi: string;
    tinh_trang: string;
    ten_nguoi_dung: string;
    avatar: string;
    anh_dai_dien: string | null;
    created_at: string;
    media: Media[];
    so_luot_thich: number;
    so_binh_luan: number;
    da_thich: boolean;
    da_luu: boolean;
};

type BinhLuan = {
    id_binh_luan: number;
    id_bai_dang: number;
    id_nguoi_dung: number;
    id_binh_luan_cha: number | null;
    noi_dung: string;
    ten_nguoi_dung: string;
    anh_dai_dien: string | null;
    so_luot_thich: number;
    da_thich: boolean;
    created_at: string;
};

const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMinutes = Math.floor(diffMs / 60000);

    if (diffMinutes < 1) return 'Vừa xong';
    if (diffMinutes < 60) return `${diffMinutes} phút trước`;

    const isToday =
        date.getDate() === now.getDate() &&
        date.getMonth() === now.getMonth() &&
        date.getFullYear() === now.getFullYear();

    if (isToday) {
        const hour = date.getHours().toString().padStart(2, '0');
        const minute = date.getMinutes().toString().padStart(2, '0');
        return `Hôm nay ${hour}:${minute}`;
    }

    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    const isYesterday =
        date.getDate() === yesterday.getDate() &&
        date.getMonth() === yesterday.getMonth() &&
        date.getFullYear() === yesterday.getFullYear();

    if (isYesterday) {
        const hour = date.getHours().toString().padStart(2, '0');
        const minute = date.getMinutes().toString().padStart(2, '0');
        return `Hôm qua ${hour}:${minute}`;
    }

    return date.toLocaleDateString('vi-VN');
};

const TrainerFeed = () => {
    const isFocused = useIsFocused();
    const [showFilter, setShowFilter] = useState(false);
    const [showCreateMenu, setShowCreateMenu] = useState(false);
    const [showCreatePost, setShowCreatePost] = useState(false);
    const [createTitle, setCreateTitle] = useState('Đăng bài huấn luyện viên');

    const [caption, setCaption] = useState('');
    const [phamViHienThi, setPhamViHienThi] = useState('0');
    const [selectedExercise, setSelectedExercise] = useState('Kỹ thuật tổng quát');
    const [selectedAchievement, setSelectedAchievement] = useState<string | null>(null);

    const [showExercisePicker, setShowExercisePicker] = useState(false);
    const [showAchievementPicker, setShowAchievementPicker] = useState(false);
    const [showPrivacyPicker, setShowPrivacyPicker] = useState(false);

    const [selectedMedia, setSelectedMedia] = useState<Asset | null>(null);
    const [baiDang, setBaiDang] = useState<BaiDang[]>([]);

    const [comments, setComments] = useState<BinhLuan[]>([]);
    const [loadingComments, setLoadingComments] = useState(false);
    const [showComments, setShowComments] = useState(false);
    const [selectedPost, setSelectedPost] = useState<BaiDang | null>(null);
    const [commentText, setCommentText] = useState('');
    const [showCommentMenu, setShowCommentMenu] = useState<number | null>(null);
    const [editingComment, setEditingComment] = useState<BinhLuan | null>(null);
    const [replyingTo, setReplyingTo] = useState<BinhLuan | null>(null);

    const [showSavedPosts, setShowSavedPosts] = useState(false);
    const [savedPostsData, setSavedPostsData] = useState<BaiDang[]>([]);
    const [loadingSavedPosts, setLoadingSavedPosts] = useState(false);

    const [showPostMenu, setShowPostMenu] = useState<number | null>(null);
    const [editingPost, setEditingPost] = useState<BaiDang | null>(null);
    const [editCaption, setEditCaption] = useState('');
    const [playingVideoId, setPlayingVideoId] = useState<number | null>(null);

    const chonMedia = async () => {
        const result = await launchImageLibrary({
            mediaType: 'mixed',
            selectionLimit: 1,
            quality: 0.8,
        });

        if (result.didCancel || result.errorCode) return;
        if (result.assets && result.assets.length > 0) {
            setSelectedMedia(result.assets[0]);
        }
    };

    const privacyLabel =
        phamViHienThi === '0'
            ? 'Cộng đồng'
            : phamViHienThi === '1'
                ? 'Học viên & Bạn bè'
                : 'Chỉ định riêng';

    const dangBai = async () => {
        if (!caption.trim() && !selectedMedia) {
            Alert.alert('Thông báo', 'Bạn hãy nhập nội dung hoặc chọn ảnh/video.');
            return;
        }

        try {
            const formData = new FormData();
            formData.append('id_nguoi_dung', '1');
            formData.append('caption', caption.trim());
            formData.append('pham_vi_hien_thi', phamViHienThi);

            if (selectedMedia?.uri) {
                const isVideo = selectedMedia.type?.startsWith('video') ||
                    selectedMedia.uri.toLowerCase().endsWith('.mp4') ||
                    selectedMedia.uri.toLowerCase().endsWith('.mov');
                const ext = isVideo ? 'mp4' : (selectedMedia.type?.includes('png') ? 'png' : 'jpg');
                const fileName = selectedMedia.fileName || `trainer_feed_${Date.now()}.${ext}`;
                const fileType = selectedMedia.type || (isVideo ? 'video/mp4' : 'image/jpeg');

                formData.append('media', {
                    uri: Platform.OS === 'android' ? selectedMedia.uri : selectedMedia.uri.replace('file://', ''),
                    type: fileType,
                    name: fileName,
                } as any);
            }

            const response = await api.post('/bai-dang', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
                transformRequest: (data) => data,
            });

            if (response.data.status) {
                Alert.alert('Thành công', 'Đăng bài thành công');
                setCaption('');
                setSelectedMedia(null);
                setShowCreatePost(false);
                await loadBaiDang();
            }
        } catch (error: any) {
            Alert.alert('Lỗi đăng bài', error.response?.data?.message || error.message || 'Không thể đăng bài');
        }
    };

    const loadBaiDang = async () => {
        try {
            const response = await api.get('/bai-dang');
            if (response.data.status) {
                const data = response.data.data.map((item: any) => ({
                    ...item,
                    ten_nguoi_dung: item.ten_nguoi_dung || 'Thành viên VisionFit',
                    avatar: item.avatar || 'VF',
                    anh_dai_dien: item.anh_dai_dien ? resolveMediaUrl(item.anh_dai_dien) : null,
                    media: (item.media || []).map((media: any) => ({
                        ...media,
                        media_url: resolveMediaUrl(media.media_url),
                    })),
                }));
                setBaiDang(data);
            }
        } catch (error) {
            console.log('Lỗi load bài đăng:', error);
        }
    };

    const toggleLike = async (item: BaiDang) => {
        try {
            if (item.da_thich) {
                await api.delete(`/bai-dang/${item.id_bai_dang}/like`);
            } else {
                await api.post(`/bai-dang/${item.id_bai_dang}/like`);
            }

            setBaiDang((prev) =>
                prev.map((post) =>
                    post.id_bai_dang === item.id_bai_dang
                        ? {
                            ...post,
                            da_thich: !post.da_thich,
                            so_luot_thich: post.da_thich ? Math.max(0, post.so_luot_thich - 1) : post.so_luot_thich + 1,
                        }
                        : post
                )
            );
        } catch (error: any) {
            console.log('Lỗi like:', error.response?.data || error.message);
        }
    };

    const toggleSave = async (item: BaiDang) => {
        try {
            if (item.da_luu) {
                await api.delete(`/bai-dang/${item.id_bai_dang}/save`);
            } else {
                await api.post(`/bai-dang/${item.id_bai_dang}/save`);
            }

            setBaiDang((prev) =>
                prev.map((post) =>
                    post.id_bai_dang === item.id_bai_dang
                        ? { ...post, da_luu: !post.da_luu }
                        : post
                )
            );
        } catch (error: any) {
            console.log('Lỗi lưu bài:', error.response?.data || error.message);
        }
    };

    const openComments = async (item: BaiDang) => {
        setSelectedPost(item);
        setShowComments(true);
        await loadComments(item.id_bai_dang);
    };

    const loadSavedPosts = async () => {
        try {
            setLoadingSavedPosts(true);
            const response = await api.get('/bai-dang-da-luu');
            if (response.data.status) {
                setSavedPostsData(response.data.data);
            }
        } catch (error: any) {
            console.log('Lỗi lấy bài đã lưu:', error.response?.data || error.message);
        } finally {
            setLoadingSavedPosts(false);
        }
    };

    const openSavedPosts = async () => {
        setShowSavedPosts(true);
        await loadSavedPosts();
    };

    const boLuuBaiDang = async (item: BaiDang) => {
        try {
            const response = await api.delete(`/bai-dang/${item.id_bai_dang}/save`);
            if (response.data.status) {
                setSavedPostsData((prev) => prev.filter((post) => post.id_bai_dang !== item.id_bai_dang));
                setBaiDang((prev) =>
                    prev.map((post) =>
                        post.id_bai_dang === item.id_bai_dang ? { ...post, da_luu: false } : post
                    )
                );
            }
        } catch (error: any) {
            console.log('Lỗi bỏ lưu:', error.response?.data || error.message);
        }
    };

    const toggleLikeComment = async (comment: BinhLuan) => {
        try {
            if (comment.da_thich) {
                await api.delete(`/binh-luan/${comment.id_binh_luan}/like`);
            } else {
                await api.post(`/binh-luan/${comment.id_binh_luan}/like`);
            }

            setComments((prev) =>
                prev.map((item) =>
                    item.id_binh_luan === comment.id_binh_luan
                        ? {
                            ...item,
                            da_thich: !item.da_thich,
                            so_luot_thich: item.da_thich ? Math.max(0, item.so_luot_thich - 1) : item.so_luot_thich + 1,
                        }
                        : item
                )
            );
        } catch (error: any) {
            console.log('Lỗi like comment:', error.response?.data || error.message);
        }
    };

    const guiBinhLuan = async () => {
        if (!commentText.trim() || !selectedPost) return;

        try {
            if (editingComment) {
                const response = await api.put(`/binh-luan/${editingComment.id_binh_luan}`, {
                    noi_dung: commentText.trim(),
                });

                if (response.data.status) {
                    setEditingComment(null);
                    setCommentText('');
                    await loadComments(selectedPost.id_bai_dang);
                }
                return;
            }

            const response = await api.post(`/bai-dang/${selectedPost.id_bai_dang}/binh-luan`, {
                noi_dung: commentText.trim(),
                id_binh_luan_cha: replyingTo?.id_binh_luan || null,
            });

            if (response.data.status) {
                setCommentText('');
                setReplyingTo(null);
                await loadComments(selectedPost.id_bai_dang);
                setBaiDang((prev) =>
                    prev.map((post) =>
                        post.id_bai_dang === selectedPost.id_bai_dang
                            ? { ...post, so_binh_luan: post.so_binh_luan + 1 }
                            : post
                    )
                );
            }
        } catch (error: any) {
            console.log('Lỗi bình luận:', error.response?.data || error.message);
        }
    };

    const suaBaiDang = async () => {
        if (!editingPost) return;
        try {
            const response = await api.put(`/bai-dang/${editingPost.id_bai_dang}`, {
                caption: editCaption.trim(),
                pham_vi_hien_thi: editingPost.pham_vi_hien_thi,
            });

            if (response.data.status) {
                setBaiDang((prev) =>
                    prev.map((post) =>
                        post.id_bai_dang === editingPost.id_bai_dang
                            ? { ...post, caption: editCaption.trim() }
                            : post
                    )
                );
                setEditingPost(null);
                setEditCaption('');
            }
        } catch (error: any) {
            Alert.alert('Lỗi', error.response?.data?.message || 'Không thể chỉnh sửa bài viết');
        }
    };

    const xoaBaiDang = (item: BaiDang) => {
        Alert.alert('Xóa bài viết', 'Bạn có chắc muốn xóa bài viết này?', [
            { text: 'Hủy', style: 'cancel' },
            {
                text: 'Xóa',
                style: 'destructive',
                onPress: async () => {
                    try {
                        const response = await api.delete(`/bai-dang/${item.id_bai_dang}`);
                        if (response.data.status) {
                            setBaiDang((prev) => prev.filter((post) => post.id_bai_dang !== item.id_bai_dang));
                            setShowPostMenu(null);
                        }
                    } catch (error: any) {
                        Alert.alert('Lỗi', error.response?.data?.message || 'Không thể xóa bài viết');
                    }
                },
            },
        ]);
    };

    useEffect(() => {
        loadBaiDang();
    }, []);

    const openCreate = (title: string) => {
        setCreateTitle(title);
        setShowCreateMenu(false);
        setShowCreatePost(true);
    };

    const loadComments = async (idBaiDang: number) => {
        try {
            setLoadingComments(true);
            const response = await api.get(`/bai-dang/${idBaiDang}/binh-luan`);
            if (response.data.status) {
                setComments(response.data.data);
            }
        } catch (error: any) {
            console.log('Lỗi load bình luận:', error.response?.data || error.message);
        } finally {
            setLoadingComments(false);
        }
    };

    const xoaBinhLuan = async (comment: BinhLuan) => {
        try {
            const response = await api.delete(`/binh-luan/${comment.id_binh_luan}`);
            if (response.data.status) {
                setComments((prev) => prev.filter((item) => item.id_binh_luan !== comment.id_binh_luan));
                if (selectedPost) {
                    setBaiDang((prev) =>
                        prev.map((post) =>
                            post.id_bai_dang === selectedPost.id_bai_dang
                                ? { ...post, so_binh_luan: Math.max(0, post.so_binh_luan - 1) }
                                : post
                        )
                    );
                }
            }
        } catch (error: any) {
            console.log('Lỗi xóa bình luận:', error.response?.data || error.message);
        }
    };

    return (
        <SafeAreaView style={styles.safe} edges={['top']}>
            {/* Chỉ đặt chữ thanh trạng thái màu tối khi tab này đang hiển thị */}
            {isFocused && <StatusBar barStyle="dark-content" />}

            <View style={styles.container}>
                {/* HEADER */}
                <View style={styles.header}>
                    <View>
                        <Text style={styles.brand}>VISIONFIT COACH</Text>
                        <TouchableOpacity
                            style={styles.titleRow}
                            onPress={() => {
                                setShowFilter(!showFilter);
                                setShowCreateMenu(false);
                            }}>
                            <Text style={styles.title}>TrainerFeed</Text>
                            <Ionicons name="chevron-down" size={17} color="#10303C" />
                        </TouchableOpacity>
                    </View>

                    <View style={styles.headerActions}>
                        <TouchableOpacity style={styles.savedButton} onPress={openSavedPosts}>
                            <Ionicons name="bookmark-outline" size={24} color="#0A3E4F" />
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={styles.addButton}
                            onPress={() => {
                                setShowCreateMenu(!showCreateMenu);
                                setShowFilter(false);
                            }}>
                            <Ionicons name="add" size={27} color="#0A3E4F" />
                        </TouchableOpacity>
                    </View>
                </View>

                {/* FILTER MENU */}
                {showFilter && (
                    <View style={styles.filterMenu}>
                        <TouchableOpacity style={styles.filterActive}>
                            <Text style={styles.filterActiveText}>Tất cả bài viết</Text>
                            <Ionicons name="checkmark" size={19} color="#0F5468" />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.filterItem}>
                            <Text style={styles.filterText}>Học viên của tôi</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.filterItem}>
                            <Text style={styles.filterText}>Mẹo & Hướng dẫn</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.filterItem}>
                            <Text style={styles.filterText}>Mới nhất</Text>
                        </TouchableOpacity>
                    </View>
                )}

                {/* CREATE MENU */}
                {showCreateMenu && (
                    <View style={styles.createMenu}>
                        <TouchableOpacity style={styles.createItem} onPress={() => openCreate('Chia sẻ kinh nghiệm')}>
                            <Ionicons name="create-outline" size={22} color="#10303C" />
                            <View style={styles.createInfo}>
                                <Text style={styles.createName}>Bài viết HLV</Text>
                                <Text style={styles.createDescription}>Kinh nghiệm, giáo án & tư vấn</Text>
                            </View>
                        </TouchableOpacity>

                        <TouchableOpacity style={styles.createItem} onPress={() => openCreate('Kỹ thuật & Mẹo tập')}>
                            <Ionicons name="fitness-outline" size={22} color="#10303C" />
                            <View style={styles.createInfo}>
                                <Text style={styles.createName}>Mẹo & Kỹ thuật</Text>
                                <Text style={styles.createDescription}>Hướng dẫn form chuẩn cho học viên</Text>
                            </View>
                        </TouchableOpacity>

                        <TouchableOpacity style={styles.createItem} onPress={() => openCreate('Thành tích học viên')}>
                            <Ionicons name="trophy-outline" size={22} color="#10303C" />
                            <View style={styles.createInfo}>
                                <Text style={styles.createName}>Thành tích học viên</Text>
                                <Text style={styles.createDescription}>Chia sẻ sự tiến bộ của hội viên</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                )}

                {/* FEED LIST */}
                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.feedContent}>
                    {/* QUICK SHARE */}
                    <TouchableOpacity
                        style={styles.quickShare}
                        activeOpacity={0.8}
                        onPress={() => openCreate('Chia sẻ từ Huấn luyện viên')}>
                        <View style={styles.myAvatar}>
                            <Text style={styles.avatarText}>HLV</Text>
                        </View>
                        <Text style={styles.quickText}>Chia sẻ bài tập, mẹo huấn luyện hoặc kết quả học viên...</Text>
                        <Ionicons name="images-outline" size={22} color="#6F8F9C" />
                    </TouchableOpacity>

                    {baiDang
                        .filter((item) => item.tinh_trang === '1')
                        .map((item) => (
                            <View style={styles.post} key={item.id_bai_dang}>
                                <View style={styles.postHeader}>
                                    {item.anh_dai_dien ? (
                                        <Image
                                            source={{ uri: item.anh_dai_dien.replace('127.0.0.1', '10.0.2.2') }}
                                            style={styles.avatarImage}
                                        />
                                    ) : (
                                        <View style={styles.avatar}>
                                            <Text style={styles.avatarText}>{item.avatar}</Text>
                                        </View>
                                    )}

                                    <View style={styles.postUser}>
                                        <Text style={styles.userName}>{item.ten_nguoi_dung}</Text>
                                        <View style={styles.postMeta}>
                                            <Text style={styles.postTime}>{formatTime(item.created_at)}</Text>
                                            <Text style={styles.dot}>•</Text>
                                            <Ionicons
                                                name={item.pham_vi_hien_thi === '0' ? 'earth-outline' : 'people-outline'}
                                                size={12}
                                                color="#6F8F9C"
                                            />
                                        </View>
                                    </View>

                                    <View style={styles.postMenuWrapper}>
                                        <TouchableOpacity
                                            style={styles.postMoreButton}
                                            onPress={() =>
                                                setShowPostMenu(showPostMenu === item.id_bai_dang ? null : item.id_bai_dang)
                                            }>
                                            <Ionicons name="ellipsis-horizontal" size={22} color="#506E73" />
                                        </TouchableOpacity>

                                        {showPostMenu === item.id_bai_dang && (
                                            <View style={styles.postMenu}>
                                                {item.id_nguoi_dung === 1 ? (
                                                    <>
                                                        <TouchableOpacity
                                                            style={styles.postMenuItem}
                                                            onPress={() => {
                                                                setEditingPost(item);
                                                                setEditCaption(item.caption || '');
                                                                setShowPostMenu(null);
                                                            }}>
                                                            <Ionicons name="create-outline" size={19} color="#10303C" />
                                                            <Text style={styles.postMenuText}>Chỉnh sửa</Text>
                                                        </TouchableOpacity>
                                                        <TouchableOpacity
                                                            style={styles.postMenuItem}
                                                            onPress={() => xoaBaiDang(item)}>
                                                            <Ionicons name="trash-outline" size={19} color="#D95B5B" />
                                                            <Text style={styles.postDeleteText}>Xóa bài viết</Text>
                                                        </TouchableOpacity>
                                                    </>
                                                ) : (
                                                    <>
                                                        <TouchableOpacity style={styles.postMenuItem}>
                                                            <Ionicons name="flag-outline" size={19} color="#10303C" />
                                                            <Text style={styles.postMenuText}>Báo cáo</Text>
                                                        </TouchableOpacity>
                                                        <TouchableOpacity style={styles.postMenuItem}>
                                                            <Ionicons name="eye-off-outline" size={19} color="#10303C" />
                                                            <Text style={styles.postMenuText}>Ẩn bài viết</Text>
                                                        </TouchableOpacity>
                                                    </>
                                                )}
                                            </View>
                                        )}
                                    </View>
                                </View>

                                {item.caption ? <Text style={styles.caption}>{item.caption}</Text> : null}

                                {item.media
                                    .sort((a, b) => a.thu_tu - b.thu_tu)
                                    .map((media) => (
                                        <View key={media.id_media}>
                                            {media.loai_media === 'image' && (
                                                <Image
                                                    source={{ uri: media.media_url }}
                                                    style={styles.postImage}
                                                    resizeMode="cover"
                                                    resizeMethod="resize"
                                                />
                                            )}

                                            {media.loai_media === 'video' && (
                                                <View style={styles.videoContainer}>
                                                    <Video
                                                        source={{ uri: media.media_url }}
                                                        style={styles.postVideo}
                                                        resizeMode="contain"
                                                        paused={playingVideoId !== media.id_media}
                                                        controls={playingVideoId === media.id_media}
                                                        onEnd={() => setPlayingVideoId(null)}
                                                    />
                                                    {playingVideoId !== media.id_media && (
                                                        <TouchableOpacity
                                                            style={styles.videoPlayOverlay}
                                                            activeOpacity={0.8}
                                                            onPress={() => setPlayingVideoId(media.id_media)}>
                                                            <View style={styles.videoPlayButton}>
                                                                <Ionicons name="play" size={30} color="#FFFFFF" />
                                                            </View>
                                                        </TouchableOpacity>
                                                    )}
                                                </View>
                                            )}
                                        </View>
                                    ))}

                                <View style={styles.actionRow}>
                                    <View style={styles.leftActions}>
                                        <TouchableOpacity style={styles.actionButton} onPress={() => toggleLike(item)}>
                                            <Ionicons
                                                name={item.da_thich ? 'heart' : 'heart-outline'}
                                                size={27}
                                                color={item.da_thich ? '#E74C3C' : '#10303C'}
                                            />
                                        </TouchableOpacity>

                                        <TouchableOpacity style={styles.actionButton} onPress={() => openComments(item)}>
                                            <Ionicons name="chatbubble-outline" size={25} color="#10303C" />
                                        </TouchableOpacity>

                                        <TouchableOpacity>
                                            <Ionicons name="paper-plane-outline" size={25} color="#10303C" />
                                        </TouchableOpacity>
                                    </View>

                                    <TouchableOpacity onPress={() => toggleSave(item)}>
                                        <Ionicons
                                            name={item.da_luu ? 'bookmark' : 'bookmark-outline'}
                                            size={26}
                                            color={item.da_luu ? '#0F5468' : '#10303C'}
                                        />
                                    </TouchableOpacity>
                                </View>

                                <View style={styles.postInfo}>
                                    <Text style={styles.likes}>{item.so_luot_thich} lượt thích</Text>
                                    <Text style={styles.postCaption}>
                                        <Text style={styles.captionUser}>{item.ten_nguoi_dung} </Text>
                                        {item.caption}
                                    </Text>
                                    <TouchableOpacity onPress={() => openComments(item)}>
                                        <Text style={styles.comments}>
                                            {item.so_binh_luan > 0 ? `Xem ${item.so_binh_luan} bình luận` : 'Thêm bình luận'}
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        ))}
                </ScrollView>

                {/* MODAL CREATE POST */}
                <Modal
                    visible={showCreatePost}
                    transparent
                    animationType="slide"
                    onRequestClose={() => setShowCreatePost(false)}>
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContent}>
                            <View style={styles.modalHandle} />
                            <View style={styles.modalHeader}>
                                <TouchableOpacity onPress={() => setShowCreatePost(false)}>
                                    <Text style={styles.cancel}>Hủy</Text>
                                </TouchableOpacity>
                                <Text style={styles.modalTitle}>{createTitle}</Text>
                                <TouchableOpacity style={styles.publish} onPress={dangBai}>
                                    <Text style={styles.publishText}>Đăng</Text>
                                </TouchableOpacity>
                            </View>

                            <View style={styles.modalUser}>
                                <View style={styles.myAvatar}>
                                    <Text style={styles.avatarText}>HLV</Text>
                                </View>
                                <View style={styles.modalUserInfo}>
                                    <Text style={styles.userName}>Huấn luyện viên VisionFit</Text>
                                    <Text style={styles.postTime}>HLV Chuyên nghiệp • Cộng đồng</Text>
                                </View>
                            </View>

                            <TextInput
                                value={caption}
                                onChangeText={setCaption}
                                multiline
                                style={styles.textArea}
                                placeholder="Chia sẻ kiến thức huấn luyện, mẹo động tác hoặc lưu ý cho học viên..."
                                placeholderTextColor="#8CA4AF"
                            />

                            <TouchableOpacity style={styles.addMedia} onPress={chonMedia}>
                                {selectedMedia ? (
                                    selectedMedia.type?.startsWith('video') ? (
                                        <View style={styles.videoSelected}>
                                            <Ionicons name="videocam-outline" size={32} color="#0A3E4F" />
                                            <Text style={styles.addMediaText}>{selectedMedia.fileName || 'Video đã chọn'}</Text>
                                            <Text style={styles.changeMedia}>Nhấn để đổi video</Text>
                                        </View>
                                    ) : (
                                        <Image source={{ uri: selectedMedia.uri }} style={styles.previewImage} resizeMode="cover" />
                                    )
                                ) : (
                                    <>
                                        <Ionicons name="image-outline" size={29} color="#0A3E4F" />
                                        <Text style={styles.addMediaText}>Thêm ảnh hoặc video bài tập</Text>
                                    </>
                                )}
                            </TouchableOpacity>

                            {/* CHỦ ĐỀ BÀI TẬP */}
                            <TouchableOpacity
                                style={styles.optionRow}
                                onPress={() => {
                                    setShowExercisePicker(!showExercisePicker);
                                    setShowAchievementPicker(false);
                                    setShowPrivacyPicker(false);
                                }}>
                                <View style={styles.optionLeft}>
                                    <Ionicons name="barbell-outline" size={21} color="#10303C" />
                                    <Text style={styles.optionText}>Chủ đề bài tập</Text>
                                </View>
                                <View style={styles.optionRight}>
                                    <Text style={styles.optionValue}>{selectedExercise}</Text>
                                    <Ionicons name={showExercisePicker ? 'chevron-up' : 'chevron-down'} size={17} color="#6F8F9C" />
                                </View>
                            </TouchableOpacity>

                            {showExercisePicker && (
                                <View style={styles.pickerBox}>
                                    {['Kỹ thuật tổng quát', 'Squat & Biến thể', 'Deadlift', 'Bench Press', 'Cardio / HIIT', 'Giãn cơ & Phục hồi'].map((item) => (
                                        <TouchableOpacity
                                            key={item}
                                            style={[styles.pickerOption, selectedExercise === item && styles.pickerOptionActive]}
                                            onPress={() => {
                                                setSelectedExercise(item);
                                                setShowExercisePicker(false);
                                            }}>
                                            <Text style={[styles.pickerText, selectedExercise === item && styles.pickerTextActive]}>{item}</Text>
                                            {selectedExercise === item && <Ionicons name="checkmark" size={18} color="#0F5468" />}
                                        </TouchableOpacity>
                                    ))}
                                </View>
                            )}

                            {/* MỤC TIÊU / THÀNH TÍCH */}
                            <TouchableOpacity
                                style={styles.optionRow}
                                onPress={() => {
                                    setShowAchievementPicker(!showAchievementPicker);
                                    setShowExercisePicker(false);
                                    setShowPrivacyPicker(false);
                                }}>
                                <View style={styles.optionLeft}>
                                    <Ionicons name="trophy-outline" size={21} color="#10303C" />
                                    <Text style={styles.optionText}>Mục tiêu / Thành tích</Text>
                                </View>
                                <View style={styles.optionRight}>
                                    <Text style={selectedAchievement ? styles.optionValue : styles.optionPlaceholder}>
                                        {selectedAchievement || 'Thêm'}
                                    </Text>
                                    <Ionicons name={showAchievementPicker ? 'chevron-up' : 'chevron-down'} size={17} color="#6F8F9C" />
                                </View>
                            </TouchableOpacity>

                            {showAchievementPicker && (
                                <View style={styles.pickerBox}>
                                    {['Kỹ thuật chuẩn form', 'Mẹo phòng tránh chấn thương', 'Thành tích học viên xuất sắc', 'Giáo án tuần mới'].map((item) => (
                                        <TouchableOpacity
                                            key={item}
                                            style={[styles.pickerOption, selectedAchievement === item && styles.pickerOptionActive]}
                                            onPress={() => {
                                                setSelectedAchievement(item);
                                                setShowAchievementPicker(false);
                                            }}>
                                            <Text style={[styles.pickerText, selectedAchievement === item && styles.pickerTextActive]}>{item}</Text>
                                            {selectedAchievement === item && <Ionicons name="checkmark" size={18} color="#0F5468" />}
                                        </TouchableOpacity>
                                    ))}
                                    <TouchableOpacity
                                        style={styles.pickerOption}
                                        onPress={() => {
                                            setSelectedAchievement(null);
                                            setShowAchievementPicker(false);
                                        }}>
                                        <Text style={styles.pickerText}>Không chọn</Text>
                                    </TouchableOpacity>
                                </View>
                            )}

                            {/* QUYỀN RIÊNG TƯ */}
                            <TouchableOpacity
                                style={styles.optionRow}
                                onPress={() => {
                                    setShowPrivacyPicker(!showPrivacyPicker);
                                    setShowExercisePicker(false);
                                    setShowAchievementPicker(false);
                                }}>
                                <View style={styles.optionLeft}>
                                    <Ionicons name="earth-outline" size={21} color="#10303C" />
                                    <Text style={styles.optionText}>Ai có thể xem?</Text>
                                </View>
                                <View style={styles.optionRight}>
                                    <Text style={styles.optionValue}>{privacyLabel}</Text>
                                    <Ionicons name={showPrivacyPicker ? 'chevron-up' : 'chevron-down'} size={17} color="#6F8F9C" />
                                </View>
                            </TouchableOpacity>

                            {showPrivacyPicker && (
                                <View style={styles.pickerBox}>
                                    {[
                                        { value: '0', label: 'Cộng đồng', icon: 'earth-outline' },
                                        { value: '1', label: 'Học viên & Bạn bè', icon: 'people-outline' },
                                        { value: '2', label: 'Chỉ định riêng', icon: 'lock-closed-outline' },
                                    ].map((item) => (
                                        <TouchableOpacity
                                            key={item.value}
                                            style={[styles.pickerOption, phamViHienThi === item.value && styles.pickerOptionActive]}
                                            onPress={() => {
                                                setPhamViHienThi(item.value);
                                                setShowPrivacyPicker(false);
                                            }}>
                                            <View style={styles.optionLeft}>
                                                <Ionicons name={item.icon} size={19} color="#10303C" />
                                                <Text style={styles.pickerLabel}>{item.label}</Text>
                                            </View>
                                            {phamViHienThi === item.value && <Ionicons name="checkmark" size={18} color="#0F5468" />}
                                        </TouchableOpacity>
                                    ))}
                                </View>
                            )}
                        </View>
                    </View>
                </Modal>
            </View>

            {/* MODAL COMMENTS */}
            <Modal
                visible={showComments}
                transparent
                animationType="slide"
                onRequestClose={() => setShowComments(false)}>
                <View style={styles.commentOverlay}>
                    <View style={styles.commentModal}>
                        <View style={styles.commentHandle} />
                        <View style={styles.commentHeader}>
                            <Text style={styles.commentTitle}>Bình luận</Text>
                            <TouchableOpacity onPress={() => setShowComments(false)}>
                                <Ionicons name="close" size={25} color="#10303C" />
                            </TouchableOpacity>
                        </View>

                        <ScrollView style={styles.commentList} showsVerticalScrollIndicator={false}>
                            {loadingComments ? (
                                <Text style={styles.commentLoading}>Đang tải bình luận...</Text>
                            ) : comments.length === 0 ? (
                                <View style={styles.commentEmpty}>
                                    <Ionicons name="chatbubbles-outline" size={42} color="#9DB5BF" />
                                    <Text style={styles.commentEmptyTitle}>Chưa có bình luận</Text>
                                    <Text style={styles.commentEmptyText}>Hãy là người đầu tiên bình luận và chia sẻ ý kiến.</Text>
                                </View>
                            ) : (
                                comments.map((comment) => (
                                    <View
                                        key={comment.id_binh_luan}
                                        style={[styles.commentItem, comment.id_binh_luan_cha ? styles.replyComment : undefined]}>
                                        <View style={styles.commentAvatar}>
                                            <Text style={styles.avatarText}>
                                                {comment.ten_nguoi_dung?.split(' ').slice(-2).map((x) => x.charAt(0)).join('').toUpperCase()}
                                            </Text>
                                        </View>

                                        <View style={styles.commentContent}>
                                            <Text style={styles.commentUser}>{comment.ten_nguoi_dung}</Text>
                                            <Text style={styles.commentBody}>{comment.noi_dung}</Text>
                                            <Text style={styles.commentTime}>{formatTime(comment.created_at)}</Text>

                                            <View style={styles.commentActions}>
                                                <TouchableOpacity onPress={() => toggleLikeComment(comment)}>
                                                    <Text style={[styles.commentActionText, comment.da_thich && styles.commentLikedText]}>
                                                        Thích
                                                    </Text>
                                                </TouchableOpacity>

                                                {comment.so_luot_thich > 0 && (
                                                    <Text style={styles.commentLikeCount}>{comment.so_luot_thich}</Text>
                                                )}

                                                <TouchableOpacity
                                                    onPress={() => {
                                                        setReplyingTo(comment);
                                                        setEditingComment(null);
                                                        setCommentText('');
                                                    }}>
                                                    <Text style={styles.commentActionText}>Trả lời</Text>
                                                </TouchableOpacity>
                                            </View>
                                        </View>

                                        {comment.id_nguoi_dung === 1 && (
                                            <View style={styles.commentMenuWrapper}>
                                                <TouchableOpacity
                                                    style={styles.commentMoreButton}
                                                    onPress={() =>
                                                        setShowCommentMenu(
                                                            showCommentMenu === comment.id_binh_luan ? null : comment.id_binh_luan
                                                        )
                                                    }>
                                                    <Ionicons name="ellipsis-horizontal" size={20} color="#6F8F9C" />
                                                </TouchableOpacity>

                                                {showCommentMenu === comment.id_binh_luan && (
                                                    <View style={styles.commentMenu}>
                                                        <TouchableOpacity
                                                            style={styles.commentMenuItem}
                                                            onPress={() => {
                                                                setEditingComment(comment);
                                                                setReplyingTo(null);
                                                                setCommentText(comment.noi_dung);
                                                                setShowCommentMenu(null);
                                                            }}>
                                                            <Ionicons name="create-outline" size={18} color="#10303C" />
                                                            <Text style={styles.commentMenuText}>Chỉnh sửa</Text>
                                                        </TouchableOpacity>

                                                        <TouchableOpacity
                                                            style={styles.commentMenuItem}
                                                            onPress={() => {
                                                                setShowCommentMenu(null);
                                                                xoaBinhLuan(comment);
                                                            }}>
                                                            <Ionicons name="trash-outline" size={18} color="#D95B5B" />
                                                            <Text style={styles.commentDeleteText}>Xóa</Text>
                                                        </TouchableOpacity>
                                                    </View>
                                                )}
                                            </View>
                                        )}
                                    </View>
                                ))
                            )}
                        </ScrollView>

                        {replyingTo && (
                            <View style={styles.inputModeBar}>
                                <Text style={styles.inputModeText}>Đang trả lời {replyingTo.ten_nguoi_dung}</Text>
                                <TouchableOpacity onPress={() => setReplyingTo(null)}>
                                    <Ionicons name="close" size={18} color="#6F8F9C" />
                                </TouchableOpacity>
                            </View>
                        )}

                        {editingComment && (
                            <View style={styles.inputModeBar}>
                                <Text style={styles.inputModeText}>Đang chỉnh sửa bình luận</Text>
                                <TouchableOpacity
                                    onPress={() => {
                                        setEditingComment(null);
                                        setCommentText('');
                                    }}>
                                    <Ionicons name="close" size={18} color="#6F8F9C" />
                                </TouchableOpacity>
                            </View>
                        )}

                        <View style={styles.commentInputRow}>
                            <View style={styles.myAvatar}>
                                <Text style={styles.avatarText}>HLV</Text>
                            </View>
                            <TextInput
                                value={commentText}
                                onChangeText={setCommentText}
                                placeholder="Thêm ý kiến huấn luyện viên..."
                                placeholderTextColor="#8CA4AF"
                                style={styles.commentInput}
                            />
                            <TouchableOpacity onPress={guiBinhLuan} disabled={!commentText.trim()}>
                                <Text style={[styles.sendComment, !commentText.trim() && styles.sendCommentDisabled]}>
                                    Đăng
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>

            {/* MODAL SAVED POSTS */}
            <Modal
                visible={showSavedPosts}
                animationType="slide"
                onRequestClose={() => setShowSavedPosts(false)}>
                <SafeAreaView style={styles.savedContainer}>
                    <View style={styles.savedHeader}>
                        <TouchableOpacity onPress={() => setShowSavedPosts(false)}>
                            <Ionicons name="arrow-back" size={25} color="#10303C" />
                        </TouchableOpacity>
                        <Text style={styles.savedTitle}>Bài viết đã lưu</Text>
                        <View style={{ width: 25 }} />
                    </View>

                    {loadingSavedPosts ? (
                        <Text style={styles.savedMessage}>Đang tải...</Text>
                    ) : savedPostsData.length === 0 ? (
                        <View style={styles.savedEmpty}>
                            <Ionicons name="bookmark-outline" size={55} color="#9DB5BF" />
                            <Text style={styles.savedEmptyTitle}>Chưa có bài viết đã lưu</Text>
                            <Text style={styles.savedEmptyText}>Những bài bạn lưu sẽ xuất hiện ở đây.</Text>
                        </View>
                    ) : (
                        <ScrollView>
                            {savedPostsData.map((item) => (
                                <View key={item.id_bai_dang} style={styles.savedPost}>
                                    <View style={styles.savedPostHeader}>
                                        <View>
                                            <Text style={styles.savedUser}>{item.ten_nguoi_dung}</Text>
                                            <Text style={styles.savedTime}>{formatTime(item.created_at)}</Text>
                                        </View>
                                        <TouchableOpacity onPress={() => boLuuBaiDang(item)}>
                                            <Ionicons name="bookmark" size={24} color="#0F5468" />
                                        </TouchableOpacity>
                                    </View>

                                    {!!item.caption && <Text style={styles.savedCaption}>{item.caption}</Text>}

                                    {item.media?.length > 0 && item.media[0].loai_media === 'image' && (
                                        <Image
                                            source={{ uri: item.media[0].media_url }}
                                            style={styles.savedImage}
                                            resizeMode="cover"
                                        />
                                    )}
                                </View>
                            ))}
                        </ScrollView>
                    )}
                </SafeAreaView>
            </Modal>

            {/* MODAL EDIT POST */}
            <Modal
                visible={editingPost !== null}
                transparent
                animationType="slide"
                onRequestClose={() => setEditingPost(null)}>
                <View style={styles.editPostOverlay}>
                    <View style={styles.editPostModal}>
                        <View style={styles.modalHandle} />
                        <View style={styles.editPostHeader}>
                            <TouchableOpacity
                                onPress={() => {
                                    setEditingPost(null);
                                    setEditCaption('');
                                }}>
                                <Text style={styles.editCancel}>Hủy</Text>
                            </TouchableOpacity>
                            <Text style={styles.editPostTitle}>Chỉnh sửa bài viết</Text>
                            <TouchableOpacity onPress={suaBaiDang}>
                                <Text style={styles.editSave}>Lưu</Text>
                            </TouchableOpacity>
                        </View>

                        <TextInput
                            value={editCaption}
                            onChangeText={setEditCaption}
                            multiline
                            placeholder="Nội dung bài viết..."
                            placeholderTextColor="#8CA4AF"
                            style={styles.editPostInput}
                        />
                    </View>
                </View>
            </Modal>
        </SafeAreaView>
    );
};

export default TrainerFeed;

const styles = StyleSheet.create({
    safe: {
        flex: 1,
        backgroundColor: '#FFFFFF',
    },
    container: {
        flex: 1,
        backgroundColor: '#F5FBFC',
    },
    header: {
        height: 76,
        paddingHorizontal: 18,
        backgroundColor: '#FFFFFF',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    brand: {
        fontSize: 11,
        fontWeight: '800',
        letterSpacing: 2,
        color: '#0F5468',
    },
    titleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 2,
    },
    title: {
        fontSize: 27,
        fontWeight: '800',
        color: '#10303C',
        marginRight: 5,
    },
    addButton: {
        width: 43,
        height: 43,
        borderRadius: 13,
        backgroundColor: '#FFFFFF',
        borderWidth: 1.2,
        borderColor: '#0F5468',
        justifyContent: 'center',
        alignItems: 'center',
    },
    filterMenu: {
        position: 'absolute',
        top: 78,
        left: 17,
        width: 215,
        padding: 7,
        backgroundColor: '#FFFFFF',
        borderRadius: 16,
        zIndex: 100,
        elevation: 10,
        shadowColor: '#000',
        shadowOpacity: 0.08,
        shadowRadius: 12,
    },
    filterActive: {
        height: 43,
        backgroundColor: '#E5F7F8',
        borderRadius: 11,
        paddingHorizontal: 13,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    filterItem: {
        height: 43,
        justifyContent: 'center',
        paddingHorizontal: 13,
    },
    filterText: {
        color: '#10303C',
        fontSize: 14,
    },
    filterActiveText: {
        color: '#0A3E4F',
        fontWeight: '700',
    },
    createMenu: {
        position: 'absolute',
        top: 72,
        right: 14,
        width: 245,
        backgroundColor: '#FFFFFF',
        borderRadius: 16,
        paddingVertical: 6,
        zIndex: 100,
        elevation: 10,
        shadowColor: '#000',
        shadowOpacity: 0.09,
        shadowRadius: 12,
    },
    createItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 11,
        paddingHorizontal: 14,
    },
    createInfo: {
        marginLeft: 13,
    },
    createName: {
        color: '#10303C',
        fontSize: 14,
        fontWeight: '700',
    },
    createDescription: {
        color: '#6F8F9C',
        fontSize: 11,
        marginTop: 2,
    },
    feedContent: {
        paddingBottom: 24,
    },
    quickShare: {
        height: 72,
        marginHorizontal: 12,
        marginVertical: 10,
        paddingHorizontal: 13,
        backgroundColor: '#FFFFFF',
        borderRadius: 18,
        borderWidth: 1,
        borderColor: '#E5F1F3',
        flexDirection: 'row',
        alignItems: 'center',
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.04,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 8,
    },
    myAvatar: {
        width: 43,
        height: 43,
        borderRadius: 22,
        backgroundColor: '#0F5468',
        alignItems: 'center',
        justifyContent: 'center',
    },
    avatar: {
        width: 42,
        height: 42,
        borderRadius: 21,
        backgroundColor: '#10A6B5',
        alignItems: 'center',
        justifyContent: 'center',
    },
    avatarText: {
        color: '#FFFFFF',
        fontWeight: '800',
        fontSize: 13,
    },
    quickText: {
        flex: 1,
        marginLeft: 12,
        fontSize: 14,
        color: '#78979C',
    },
    post: {
        backgroundColor: '#FFFFFF',
        marginHorizontal: 12,
        marginBottom: 14,
        borderRadius: 18,
        borderWidth: 1,
        borderColor: '#E5F1F3',
        overflow: 'hidden',
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.04,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 8,
    },
    postHeader: {
        height: 64,
        paddingHorizontal: 14,
        flexDirection: 'row',
        alignItems: 'center',
    },
    postUser: {
        flex: 1,
        marginLeft: 11,
    },
    postMeta: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 2,
    },
    dot: {
        marginHorizontal: 5,
        color: '#6F8F9C',
        fontSize: 11,
    },
    userName: {
        fontSize: 15,
        fontWeight: '700',
        color: '#10303C',
    },
    postTime: {
        color: '#6F8F9C',
        fontSize: 12,
        marginTop: 2,
    },
    caption: {
        paddingHorizontal: 14,
        paddingBottom: 12,
        color: '#10303C',
        fontSize: 14,
        lineHeight: 20,
    },
    postImage: {
        width: '100%',
        height: 390,
        backgroundColor: '#E6F0F4',
    },
    actionRow: {
        height: 50,
        paddingHorizontal: 14,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    leftActions: {
        flexDirection: 'row',
    },
    actionButton: {
        marginRight: 17,
    },
    postInfo: {
        paddingHorizontal: 14,
        paddingBottom: 13,
    },
    likes: {
        fontWeight: '700',
        fontSize: 13,
        color: '#10303C',
    },
    postCaption: {
        marginTop: 5,
        color: '#10303C',
        fontSize: 13,
    },
    captionUser: {
        fontWeight: '700',
    },
    comments: {
        marginTop: 6,
        color: '#83999D',
        fontSize: 13,
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.25)',
        justifyContent: 'flex-end',
    },
    modalContent: {
        backgroundColor: '#FFFFFF',
        borderTopLeftRadius: 25,
        borderTopRightRadius: 25,
        paddingHorizontal: 18,
        paddingBottom: 25,
        minHeight: '75%',
    },
    modalHandle: {
        width: 45,
        height: 4,
        backgroundColor: '#DCE4E6',
        borderRadius: 10,
        alignSelf: 'center',
        marginTop: 8,
        marginBottom: 13,
    },
    modalHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    cancel: {
        color: '#6F8F9C',
        fontWeight: '600',
    },
    modalTitle: {
        fontSize: 18,
        fontWeight: '800',
        color: '#10303C',
    },
    publish: {
        backgroundColor: '#0F5468',
        paddingHorizontal: 15,
        paddingVertical: 9,
        borderRadius: 12,
    },
    publishText: {
        color: '#FFFFFF',
        fontWeight: '700',
    },
    modalUser: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 20,
    },
    modalUserInfo: {
        marginLeft: 11,
    },
    textArea: {
        minHeight: 110,
        marginTop: 18,
        fontSize: 15,
        color: '#10303C',
        textAlignVertical: 'top',
    },
    addMedia: {
        height: 120,
        backgroundColor: '#F1FAFB',
        borderRadius: 16,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 12,
    },
    addMediaText: {
        color: '#0A3E4F',
        fontWeight: '700',
        marginTop: 7,
    },
    optionRow: {
        height: 53,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    optionLeft: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    optionText: {
        marginLeft: 12,
        fontSize: 14,
        color: '#10303C',
    },
    optionValue: {
        color: '#0F5468',
        fontWeight: '600',
    },
    optionPlaceholder: {
        color: '#82999D',
    },
    previewImage: {
        width: '100%',
        height: '100%',
        borderRadius: 16,
    },
    videoSelected: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    changeMedia: {
        marginTop: 5,
        fontSize: 11,
        color: '#6F8F9C',
    },
    avatarImage: {
        width: 42,
        height: 42,
        borderRadius: 21,
    },
    optionRight: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 7,
    },
    pickerBox: {
        backgroundColor: '#F5FBFC',
        borderRadius: 14,
        padding: 6,
        marginBottom: 8,
    },
    pickerOption: {
        minHeight: 44,
        paddingHorizontal: 12,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderRadius: 10,
    },
    pickerOptionActive: {
        backgroundColor: '#E2F6F8',
    },
    pickerText: {
        fontSize: 14,
        color: '#10303C',
    },
    pickerTextActive: {
        color: '#0F5468',
        fontWeight: '700',
    },
    pickerLabel: {
        marginLeft: 10,
        fontSize: 14,
        color: '#10303C',
    },
    commentOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.25)',
        justifyContent: 'flex-end',
    },
    commentModal: {
        height: '62%',
        backgroundColor: '#FFFFFF',
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        paddingHorizontal: 16,
    },
    commentHandle: {
        width: 45,
        height: 4,
        borderRadius: 2,
        backgroundColor: '#D8E3E5',
        alignSelf: 'center',
        marginTop: 8,
        marginBottom: 12,
    },
    commentHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingBottom: 12,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: '#D5E5EC',
    },
    commentTitle: {
        fontSize: 17,
        fontWeight: '800',
        color: '#10303C',
    },
    commentEmpty: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    commentEmptyTitle: {
        marginTop: 10,
        fontSize: 16,
        fontWeight: '700',
        color: '#10303C',
    },
    commentEmptyText: {
        marginTop: 4,
        fontSize: 13,
        color: '#6F8F9C',
    },
    commentInputRow: {
        minHeight: 68,
        flexDirection: 'row',
        alignItems: 'center',
        borderTopWidth: StyleSheet.hairlineWidth,
        borderTopColor: '#D5E5EC',
    },
    commentInput: {
        flex: 1,
        marginHorizontal: 10,
        fontSize: 14,
        color: '#10303C',
    },
    sendComment: {
        color: '#0F5468',
        fontWeight: '700',
        fontSize: 14,
    },
    sendCommentDisabled: {
        opacity: 0.35,
    },
    commentList: {
        flex: 1,
    },
    commentLoading: {
        textAlign: 'center',
        marginTop: 30,
        color: '#6F8F9C',
    },
    commentItem: {
        flexDirection: 'row',
        paddingVertical: 12,
    },
    commentAvatar: {
        width: 38,
        height: 38,
        borderRadius: 19,
        backgroundColor: '#DDF3F5',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 10,
    },
    commentContent: {
        flex: 1,
    },
    commentUser: {
        fontSize: 14,
        fontWeight: '700',
        color: '#10303C',
    },
    commentBody: {
        marginTop: 2,
        fontSize: 14,
        lineHeight: 20,
        color: '#24484E',
    },
    commentTime: {
        marginTop: 4,
        fontSize: 11,
        color: '#8CA4AF',
    },
    deleteCommentButton: {
        padding: 6,
    },
    savedContainer: {
        flex: 1,
        backgroundColor: '#FFFFFF',
    },
    savedHeader: {
        height: 56,
        paddingHorizontal: 16,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: '#D5E5EC',
    },
    savedTitle: {
        fontSize: 18,
        fontWeight: '800',
        color: '#10303C',
    },
    savedMessage: {
        textAlign: 'center',
        marginTop: 40,
        color: '#6F8F9C',
    },
    savedEmpty: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    savedEmptyTitle: {
        marginTop: 12,
        fontSize: 17,
        fontWeight: '700',
        color: '#10303C',
    },
    savedEmptyText: {
        marginTop: 5,
        fontSize: 13,
        color: '#6F8F9C',
    },
    savedPost: {
        paddingVertical: 15,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: '#D5E5EC',
    },
    savedPostHeader: {
        paddingHorizontal: 16,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    savedUser: {
        fontSize: 14,
        fontWeight: '700',
        color: '#10303C',
    },
    savedTime: {
        marginTop: 2,
        fontSize: 11,
        color: '#81999D',
    },
    savedCaption: {
        paddingHorizontal: 16,
        marginTop: 10,
        marginBottom: 10,
        fontSize: 14,
        color: '#24484E',
    },
    savedImage: {
        width: '100%',
        height: 280,
    },
    headerActions: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
    savedButton: {
        width: 43,
        height: 43,
        borderRadius: 13,
        backgroundColor: '#FFFFFF',
        borderWidth: 1.2,
        borderColor: '#D5E5EC',
        justifyContent: 'center',
        alignItems: 'center',
    },
    commentMenuWrapper: {
        position: 'relative',
    },
    commentMoreButton: {
        padding: 6,
    },
    commentMenu: {
        position: 'absolute',
        right: 5,
        top: 30,
        width: 135,
        backgroundColor: '#FFFFFF',
        borderRadius: 12,
        paddingVertical: 5,
        elevation: 8,
        zIndex: 100,
    },
    commentMenuItem: {
        minHeight: 42,
        paddingHorizontal: 12,
        flexDirection: 'row',
        alignItems: 'center',
    },
    commentMenuText: {
        marginLeft: 9,
        fontSize: 13,
        color: '#10303C',
    },
    commentDeleteText: {
        marginLeft: 9,
        fontSize: 13,
        color: '#D95B5B',
    },
    commentActions: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 6,
        gap: 14,
    },
    commentActionText: {
        fontSize: 12,
        fontWeight: '600',
        color: '#6F8F9C',
    },
    commentLikedText: {
        color: '#0F5468',
    },
    commentLikeCount: {
        fontSize: 11,
        color: '#6F8F9C',
        marginLeft: -8,
    },
    replyComment: {
        marginLeft: 42,
    },
    inputModeBar: {
        height: 37,
        paddingHorizontal: 8,
        backgroundColor: '#F1FAFB',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    inputModeText: {
        fontSize: 12,
        color: '#50757B',
    },
    postMenuWrapper: {
        position: 'relative',
    },
    postMoreButton: {
        padding: 5,
    },
    postMenu: {
        position: 'absolute',
        right: 0,
        top: 32,
        width: 165,
        backgroundColor: '#FFFFFF',
        borderRadius: 13,
        paddingVertical: 5,
        elevation: 10,
        zIndex: 200,
        shadowColor: '#000',
        shadowOpacity: 0.08,
        shadowRadius: 10,
    },
    postMenuItem: {
        minHeight: 45,
        paddingHorizontal: 13,
        flexDirection: 'row',
        alignItems: 'center',
    },
    postMenuText: {
        marginLeft: 10,
        fontSize: 13,
        color: '#10303C',
    },
    postDeleteText: {
        marginLeft: 10,
        fontSize: 13,
        color: '#D95B5B',
    },
    editPostOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.25)',
        justifyContent: 'flex-end',
    },
    editPostModal: {
        minHeight: '45%',
        backgroundColor: '#FFFFFF',
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        paddingHorizontal: 18,
        paddingBottom: 25,
    },
    editPostHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    editPostTitle: {
        fontSize: 17,
        fontWeight: '800',
        color: '#10303C',
    },
    editCancel: {
        fontSize: 14,
        color: '#6F8F9C',
    },
    editSave: {
        fontSize: 14,
        fontWeight: '700',
        color: '#0F5468',
    },
    editPostInput: {
        minHeight: 150,
        marginTop: 20,
        fontSize: 15,
        color: '#10303C',
        textAlignVertical: 'top',
    },
    videoContainer: {
        width: '100%',
        height: 390,
        backgroundColor: '#000000',
        position: 'relative',
    },
    postVideo: {
        width: '100%',
        height: '100%',
        backgroundColor: '#000000',
    },
    videoPlayOverlay: {
        ...StyleSheet.absoluteFill,
        alignItems: 'center',
        justifyContent: 'center',
    },
    videoPlayButton: {
        width: 62,
        height: 62,
        borderRadius: 31,
        backgroundColor: 'rgba(0,0,0,0.55)',
        alignItems: 'center',
        justifyContent: 'center',
    },
});
