import React, { useState, useRef, useEffect, useCallback } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    TextInput,
    Image,
    ScrollView,
    Modal,
    Alert,
    StatusBar,
    KeyboardAvoidingView,
    Platform,
    ActivityIndicator,
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import { launchImageLibrary } from "react-native-image-picker";
import { SafeAreaView } from "react-native-safe-area-context";
import LinearGradient from "react-native-linear-gradient";
import apiFitlife, { BASE_URL } from "../../general/api";
import { COLORS, SHADOWS } from "../../general/theme";

const EMOJI_LIST = ["❤️", "👍", "🔥", "😂", "😮", "😢"];

const getImageUrl = (url: string | null) => {
    if (!url) return '';
    if (url.startsWith('http://') || url.startsWith('https://')) return url;
    return `${BASE_URL}${url}`;
};

const ChatRoom = ({ navigation, route }: any) => {
    const conversation = route?.params?.conversation || {};
    const currentUser = route?.params?.currentUser || {
        id_nguoi_dung: 1,
        ho_ten: "Lê Hoàng Nam",
    };

    const isGroup = conversation.loai === "NHOM";
    const partner = conversation.doi_phuong;
    const displayName = isGroup ? conversation.ten_nhom : (partner?.ho_ten || "Cuộc trò chuyện");
    const displayAvatar = isGroup
        ? getImageUrl(conversation.anh_nhom || "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&auto=format&fit=crop&q=80")
        : getImageUrl(partner?.anh_dai_dien || "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&auto=format&fit=crop&q=80");

    const [messages, setMessages] = useState<any[]>([]);
    const [isMessagesLoading, setIsMessagesLoading] = useState<boolean>(true);
    const [inputText, setInputText] = useState("");
    const [replyingTo, setReplyingTo] = useState<any>(null);
    const [isTyping, setIsTyping] = useState(false);
    const [selectedMsgForReaction, setSelectedMsgForReaction] = useState<any>(null);
    const [showInfoModal, setShowInfoModal] = useState(false);
    const [showAttachMenu, setShowAttachMenu] = useState(false);
    const [previewImage, setPreviewImage] = useState<string | null>(null);
    const [confirmedWorkout, setConfirmedWorkout] = useState(false);

    const flatListRef = useRef<FlatList>(null);

    useEffect(() => {
        fetchMessages();

        // Polling định kỳ mỗi 3.5s để cập nhật tin nhắn mới
        const interval = setInterval(() => {
            const roomUuid = conversation?.room_uuid;
            const roomId = conversation?.id_cuoc_tro_chuyen;
            apiFitlife.get("/chat/history-message", {
                params: {
                    room_uuid: roomUuid,
                    room_id: roomId,
                },
            }).then((res) => {
                if (res.data && res.data.status && Array.isArray(res.data.data)) {
                    setMessages(res.data.data);
                }
            }).catch((err) => {
                console.error("Polling error:", err);
            });
        }, 3500);

        return () => clearInterval(interval);
    }, [conversation?.room_uuid, conversation?.id_cuoc_tro_chuyen]);

    // Tải lịch sử tin nhắn từ Backend theo phong cách WorkoutPlanScreen
    const fetchMessages = async () => {
        try {
            setIsMessagesLoading(true);
            const roomUuid = conversation?.room_uuid;
            const roomId = conversation?.id_cuoc_tro_chuyen;
            const response = await apiFitlife.get("/chat/history-message", {
                params: {
                    room_uuid: roomUuid,
                    room_id: roomId,
                },
            });
            if (response.data && response.data.status) {
                setMessages(response.data.data);
            }
        } catch (error) {
            console.error("Error fetching chat history:", error);
        } finally {
            setIsMessagesLoading(false);
        }
    };

    // Gửi tin nhắn mới
    const handleSend = async (text: string, type: string = "VAN_BAN", mediaUrl?: string, workoutData?: any) => {
        if (!text.trim() && !mediaUrl && type === "VAN_BAN") return;

        const now = new Date();
        const time = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;

        const tempId = Date.now();
        const newMsg: any = {
            id_tin_nhan: tempId,
            id_nguoi_gui: currentUser.id_nguoi_dung,
            loai_tin_nhan: type,
            noi_dung: text,
            media_url: mediaUrl,
            workout: workoutData,
            trang_thai: "DA_GUI",
            thoi_gian_gui: time,
            da_xem: false,
        };

        if (replyingTo) {
            newMsg.id_tin_nhan_tra_loi = replyingTo.id_tin_nhan;
            newMsg.tra_loi_noi_dung = replyingTo.noi_dung;
            newMsg.tra_loi_nguoi_gui = replyingTo.id_nguoi_gui === currentUser.id_nguoi_dung ? "Bạn" : partner?.ho_ten;
        }

        setMessages((prev) => [...prev, newMsg]);
        setInputText("");
        setReplyingTo(null);

        setTimeout(() => {
            flatListRef.current?.scrollToEnd({ animated: true });
        }, 100);

        // Gửi lên Backend
        try {
            const res = await apiFitlife.post("/chat/send-message", {
                room_uuid: conversation.room_uuid,
                room_id: conversation.id_cuoc_tro_chuyen,
                message: text,
                message_type: type,
                media_url: mediaUrl,
                workout: workoutData,
                id_tin_nhan_tra_loi: replyingTo?.id_tin_nhan,
            });

            if (res.data && res.data.status && res.data.data) {
                const savedMsg = res.data.data;
                setMessages((prev) =>
                    prev.map((m) => (m.id_tin_nhan === tempId ? { ...m, ...savedMsg, id_tin_nhan: savedMsg.id_tin_nhan || savedMsg.id } : m))
                );
            }
        } catch (err) {
            console.log("Lỗi khi gửi tin nhắn lên Backend:", err);
        }
    };

    // Chọn ảnh từ thư viện bằng react-native-image-picker
    const handlePickImage = async () => {
        try {
            const result = await launchImageLibrary({ mediaType: "photo", quality: 0.8 });
            if (result.assets && result.assets.length > 0 && result.assets[0].uri) {
                const asset = result.assets[0];

                // Upload lên server backend
                try {
                    const formData = new FormData();
                    formData.append("file", {
                        uri: asset.uri,
                        type: asset.type || "image/jpeg",
                        name: asset.fileName || `chat_${Date.now()}.jpg`,
                    } as any);

                    const uploadRes = await apiFitlife.post("/chat/upload", formData, {
                        headers: { "Content-Type": "multipart/form-data" },
                    });

                    if (uploadRes.data && uploadRes.data.status && uploadRes.data.url) {
                        handleSend("Đã gửi một hình ảnh", "HINH_ANH", uploadRes.data.url);
                        return;
                    }
                } catch (uploadError) {
                    console.log("Upload ảnh lên Backend thất bại, dùng ảnh local:", uploadError);
                }

                handleSend("Đã gửi một hình ảnh", "HINH_ANH", asset.uri);
            }
        } catch (e) {
            console.log("Lỗi khi chọn ảnh:", e);
        }
    };

    // Thả reaction
    const handleAddReaction = async (msgId: number, emoji: string) => {
        setMessages((prev) =>
            prev.map((m) => {
                if (m.id_tin_nhan !== msgId) return m;
                const reactions = m.reactions || [];
                const hasReacted = reactions.includes(emoji);
                return {
                    ...m,
                    reactions: hasReacted ? reactions.filter((r: string) => r !== emoji) : [...reactions, emoji],
                };
            })
        );
        setSelectedMsgForReaction(null);

        try {
            await apiFitlife.post(`/chat/message/${msgId}/reaction`, { emoji });
        } catch (e) {
            console.log("Lỗi gửi reaction lên Backend:", e);
        }
    };

    // Thu hồi tin nhắn
    const handleRecall = async (msgId: number) => {
        setMessages((prev) =>
            prev.map((m) =>
                m.id_tin_nhan === msgId
                    ? { ...m, trang_thai: "DA_THU_HOI", noi_dung: "Tin nhắn đã được thu hồi", media_url: null, workout: null }
                    : m
            )
        );
        setSelectedMsgForReaction(null);

        try {
            await apiFitlife.post(`/chat/message/${msgId}/recall`);
        } catch (e) {
            console.log("Lỗi thu hồi tin nhắn trên Backend:", e);
        }
    };

    return (
        <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
            <StatusBar barStyle="dark-content" />

            {/* Header phòng chat */}
            <View style={styles.headerWrap}>
            <LinearGradient
                colors={[COLORS.primary, COLORS.primaryDark]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.header}
            >
                <View style={styles.headerCircle} />
                <TouchableOpacity style={styles.headerBackBtn} onPress={() => navigation.goBack()}>
                    <Ionicons name="chevron-back" size={22} color={COLORS.white} />
                </TouchableOpacity>

                <TouchableOpacity style={styles.headerUserInfo} activeOpacity={0.7} onPress={() => setShowInfoModal(true)}>
                    <View style={styles.headerAvatarWrap}>
                        <Image source={{ uri: displayAvatar }} style={styles.headerAvatar} />
                        {!isGroup && partner?.online && <View style={styles.headerOnlineDot} />}
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.headerName} numberOfLines={1}>
                            {displayName}
                        </Text>
                        <View style={{ flexDirection: "row", alignItems: "center", marginTop: 2 }}>
                            <Text style={styles.headerStatus}>
                                {isGroup ? "Nhóm 8 thành viên" : partner?.online ? "Đang hoạt động" : "Hoạt động gần đây"}
                            </Text>
                            {partner?.vai_tro === "HUAN_LUYEN_VIEN" && (
                                <View style={styles.headerPtTag}>
                                    <Text style={styles.headerPtTagText}>HLV</Text>
                                </View>
                            )}
                        </View>
                    </View>
                </TouchableOpacity>

                <View style={styles.headerActions}>
                    <TouchableOpacity style={styles.headerActionBtn} onPress={() => Alert.alert("Cuộc gọi thoại", `Đang gọi thoại tới ${displayName}...`)}>
                        <Ionicons name="call" size={17} color={COLORS.white} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.headerActionBtn} onPress={() => Alert.alert("Cuộc gọi Video", `Đang kết nối video call với ${displayName}...`)}>
                        <Ionicons name="videocam" size={18} color={COLORS.white} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.headerActionBtn} onPress={() => setShowInfoModal(true)}>
                        <Ionicons name="information-circle" size={20} color={COLORS.white} />
                    </TouchableOpacity>
                </View>
            </LinearGradient>
            </View>

            {/* Khung tin nhắn */}
            <KeyboardAvoidingView style={styles.chatBody} behavior={Platform.OS === "ios" ? "padding" : undefined}>
                {isMessagesLoading ? (
                    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                        <ActivityIndicator size="large" color="#0F5468" />
                    </View>
                ) : (
                    <FlatList
                        ref={flatListRef}
                        data={messages}
                        keyExtractor={(item, index) => (item.id_tin_nhan || item.id ? `${item.id_tin_nhan || item.id}` : `msg_${index}`)}
                        showsVerticalScrollIndicator={false}
                        contentContainerStyle={[styles.messagesList, messages.length === 0 && { flexGrow: 1, justifyContent: "center", alignItems: "center" }]}
                        onLayout={() => flatListRef.current?.scrollToEnd({ animated: false })}
                        ListEmptyComponent={
                            <View style={{ alignItems: "center", justifyContent: "center", paddingVertical: 40 }}>
                                <Ionicons name="chatbubbles-outline" size={48} color="#6F8F9C" style={{ marginBottom: 12 }} />
                                <Text style={{ fontSize: 16, fontWeight: "700", color: COLORS.textPrimary }}>Chưa có tin nhắn nào</Text>
                                <Text style={{ fontSize: 13, color: "#6F8F9C", marginTop: 4 }}>Hãy gửi lời chào để bắt đầu cuộc trò chuyện!</Text>
                            </View>
                        }
                        renderItem={({ item }) => {
                            const isSender = item.id_nguoi_gui === currentUser.id_nguoi_dung;
                            const isRecalled = item.trang_thai === "DA_THU_HOI";

                            return (
                                <View style={[styles.msgRow, isSender ? styles.msgRowSender : styles.msgRowReceiver]}>
                                    {!isSender && <Image source={{ uri: displayAvatar }} style={styles.msgAvatar} />}

                                    <View style={styles.msgBubbleWrap}>
                                        {/* Trích dẫn trả lời */}
                                        {item.tra_loi_noi_dung && (
                                            <View style={[styles.replyBox, isSender ? styles.replyBoxSender : styles.replyBoxReceiver]}>
                                                <View style={styles.replyLine} />
                                                <View style={{ flex: 1 }}>
                                                    <Text style={styles.replyAuthor}>{item.tra_loi_nguoi_gui}</Text>
                                                    <Text style={styles.replyText} numberOfLines={1}>
                                                        {item.tra_loi_noi_dung}
                                                    </Text>
                                                </View>
                                            </View>
                                        )}

                                        {/* Bong bóng tin nhắn */}
                                        <TouchableOpacity
                                            style={[
                                                styles.bubble,
                                                isSender ? styles.bubbleSender : styles.bubbleReceiver,
                                                isRecalled && styles.bubbleRecalled,
                                            ]}
                                            activeOpacity={0.85}
                                            onLongPress={() => setSelectedMsgForReaction(item)}
                                        >
                                            {isRecalled ? (
                                                <View style={{ flexDirection: "row", alignItems: "center" }}>
                                                    <Ionicons name="ban" size={16} color="#6F8F9C" style={{ marginRight: 6 }} />
                                                    <Text style={styles.recalledText}>Tin nhắn đã được thu hồi</Text>
                                                </View>
                                            ) : (
                                                <>
                                                    {/* Ảnh */}
                                                    {item.media_url && (
                                                        <TouchableOpacity activeOpacity={0.9} onPress={() => setPreviewImage(getImageUrl(item.media_url))}>
                                                            <Image source={{ uri: getImageUrl(item.media_url) }} style={styles.bubbleImage} />
                                                        </TouchableOpacity>
                                                    )}

                                                    {/* Thẻ lịch tập thể hình */}
                                                    {item.loai_tin_nhan === "LICH_TAP" && item.workout && (
                                                        <View style={styles.workoutCard}>
                                                            <View style={{ flexDirection: "row", alignItems: "center" }}>
                                                                <View style={styles.workoutIconWrap}>
                                                                    <Ionicons name="barbell" size={18} color="#FFFFFF" />
                                                                </View>
                                                                <View style={{ flex: 1, marginLeft: 8 }}>
                                                                    <Text style={styles.workoutTag}>BUỔI TẬP VISIONFIT</Text>
                                                                    <Text style={styles.workoutTitle}>{item.workout.ten_bai_tap}</Text>
                                                                </View>
                                                            </View>

                                                            <View style={styles.workoutDivider} />

                                                            <View style={{ marginBottom: 10 }}>
                                                                <View style={styles.workoutDetailRow}>
                                                                    <Ionicons name="calendar-outline" size={14} color="#0F5468" />
                                                                    <Text style={styles.workoutDetailText}>{item.workout.ngay_tap}</Text>
                                                                </View>
                                                                <View style={styles.workoutDetailRow}>
                                                                    <Ionicons name="time-outline" size={14} color="#0F5468" />
                                                                    <Text style={styles.workoutDetailText}>{item.workout.gio_tap}</Text>
                                                                </View>
                                                                <View style={styles.workoutDetailRow}>
                                                                    <Ionicons name="flame-outline" size={14} color={COLORS.accentRed} />
                                                                    <Text style={styles.workoutDetailText}>Mục tiêu: {item.workout.calo_muc_tieu} kcal</Text>
                                                                </View>
                                                            </View>

                                                            <TouchableOpacity
                                                                style={[styles.confirmBtn, confirmedWorkout && styles.confirmedBtn]}
                                                                onPress={() => {
                                                                    setConfirmedWorkout(true);
                                                                    Alert.alert("Thành công", "Đã lưu lịch tập vào Lịch tập luyện cá nhân của bạn!");
                                                                }}
                                                            >
                                                                <Ionicons name={confirmedWorkout ? "checkmark-circle" : "calendar"} size={16} color="#FFFFFF" style={{ marginRight: 6 }} />
                                                                <Text style={styles.confirmBtnText}>{confirmedWorkout ? "Đã xác nhận lịch" : "Xác nhận lịch tập"}</Text>
                                                            </TouchableOpacity>
                                                        </View>
                                                    )}

                                                    {/* Text */}
                                                    {item.noi_dung ? (
                                                        <Text style={[styles.bubbleText, isSender ? styles.bubbleTextSender : styles.bubbleTextReceiver]}>
                                                            {item.noi_dung}
                                                        </Text>
                                                    ) : null}
                                                </>
                                            )}

                                            {/* Reactions */}
                                            {item.reactions && (Array.isArray(item.reactions) ? item.reactions.length > 0 : Boolean(item.reactions)) && (
                                                <View style={[styles.reactionBadge, isSender ? { right: 8 } : { left: 8 }]}>
                                                    {(Array.isArray(item.reactions) ? item.reactions : [item.reactions]).map((r: string, idx: number) => (
                                                        <Text key={`reaction_${idx}_${r}`} style={{ fontSize: 12 }}>
                                                            {r}
                                                        </Text>
                                                    ))}
                                                </View>
                                            )}
                                        </TouchableOpacity>

                                        {/* Thời gian */}
                                        <View style={[styles.timeRow, isSender ? { justifyContent: "flex-end" } : { justifyContent: "flex-start" }]}>
                                            <Text style={styles.timeText}>{item.thoi_gian_gui}</Text>
                                            {isSender && (
                                                <Ionicons
                                                    name={item.da_xem ? "checkmark-done" : "checkmark"}
                                                    size={13}
                                                    color={item.da_xem ? "#0F5468" : "#6F8F9C"}
                                                    style={{ marginLeft: 4 }}
                                                />
                                            )}
                                        </View>
                                    </View>
                                </View>
                            );
                        }}
                        ListFooterComponent={
                            isTyping ? (
                                <View style={[styles.msgRow, styles.msgRowReceiver, { marginBottom: 12 }]}>
                                    <Image source={{ uri: displayAvatar }} style={styles.msgAvatar} />
                                    <View style={[styles.bubble, styles.bubbleReceiver, styles.typingBubble]}>
                                        <View style={styles.typingDot} />
                                        <View style={[styles.typingDot, { opacity: 0.7 }]} />
                                        <View style={[styles.typingDot, { opacity: 0.4 }]} />
                                    </View>
                                </View>
                            ) : undefined
                        }
                    />
                )}

                {/* Thanh nhập tin nhắn Messenger */}
                <View style={styles.toolbar}>
                    {/* Banner trả lời */}
                    {replyingTo && (
                        <View style={styles.replyBanner}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.replyBannerTitle}>
                                    Đang trả lời <Text style={{ fontWeight: "bold" }}>{replyingTo.id_nguoi_gui === currentUser.id_nguoi_dung ? "chính bạn" : partner?.ho_ten}</Text>
                                </Text>
                                <Text style={styles.replyBannerText} numberOfLines={1}>
                                    {replyingTo.noi_dung}
                                </Text>
                            </View>
                            <TouchableOpacity onPress={() => setReplyingTo(null)}>
                                <Ionicons name="close" size={18} color="#6F8F9C" />
                            </TouchableOpacity>
                        </View>
                    )}

                    {/* Menu đính kèm nhanh */}
                    {showAttachMenu && (
                        <View style={styles.attachMenu}>
                            <TouchableOpacity
                                style={styles.attachItem}
                                onPress={() => {
                                    setShowAttachMenu(false);
                                    handleSend("Đề xuất bài tập bổ trợ", "LICH_TAP", undefined, {
                                        ten_bai_tap: "Cardio HIIT Đốt mỡ cuối buổi (Tabata 15 phút)",
                                        ngay_tap: "Hôm nay",
                                        gio_tap: "19:30",
                                        calo_muc_tieu: 220,
                                    });
                                }}
                            >
                                <View style={[styles.attachIconWrap, { backgroundColor: "#DFF6F8" }]}>
                                    <Ionicons name="barbell" size={20} color="#0F5468" />
                                </View>
                                <Text style={styles.attachLabel}>Gửi bài tập</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.attachItem}
                                onPress={() => {
                                    setShowAttachMenu(false);
                                    handlePickImage();
                                }}
                            >
                                <View style={[styles.attachIconWrap, { backgroundColor: "#E8F5E9" }]}>
                                    <Ionicons name="nutrition" size={20} color="#2E7D32" />
                                </View>
                                <Text style={styles.attachLabel}>Bữa ăn/Calo</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.attachItem}
                                onPress={() => {
                                    setShowAttachMenu(false);
                                    Alert.alert("Tài liệu giáo trình", "Đính kèm file PDF giáo trình tập");
                                }}
                            >
                                <View style={[styles.attachIconWrap, { backgroundColor: "#EDE7F6" }]}>
                                    <Ionicons name="document-text" size={20} color="#5E35B1" />
                                </View>
                                <Text style={styles.attachLabel}>Tài liệu</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.attachItem}
                                onPress={() => {
                                    setShowAttachMenu(false);
                                    Alert.alert("Vị trí", "Gửi vị trí phòng tập VisionFit");
                                }}
                            >
                                <View style={[styles.attachIconWrap, { backgroundColor: "#FFF3E0" }]}>
                                    <Ionicons name="location" size={20} color="#E65100" />
                                </View>
                                <Text style={styles.attachLabel}>Vị trí Gym</Text>
                            </TouchableOpacity>
                        </View>
                    )}

                    <View style={styles.toolbarInputRow}>
                        <TouchableOpacity style={styles.toolIconBtn} onPress={() => setShowAttachMenu(!showAttachMenu)}>
                            <Ionicons name={showAttachMenu ? "close-circle" : "add-circle"} size={26} color="#0F5468" />
                        </TouchableOpacity>

                        <TouchableOpacity style={styles.toolIconBtn} onPress={() => Alert.alert("Camera", "Chụp ảnh bài tập")}>
                            <Ionicons name="camera" size={24} color="#0F5468" />
                        </TouchableOpacity>

                        <TouchableOpacity style={styles.toolIconBtn} onPress={handlePickImage}>
                            <Ionicons name="images" size={23} color="#0F5468" />
                        </TouchableOpacity>

                        <View style={styles.inputBox}>
                            <TextInput
                                style={styles.input}
                                placeholder="Nhắn tin..."
                                placeholderTextColor="#6F8F9C"
                                value={inputText}
                                onChangeText={setInputText}
                                multiline
                            />
                            <TouchableOpacity style={styles.emojiBtn} onPress={() => setInputText((prev) => prev + " 😊")}>
                                <Ionicons name="happy-outline" size={22} color={COLORS.textMuted} />
                            </TouchableOpacity>
                        </View>

                        {/* Nút Like 👍 khi trống, nút Gửi ✈️ khi có chữ */}
                        {inputText.trim().length === 0 ? (
                            <TouchableOpacity style={styles.likeBtn} onPress={() => handleSend("👍")} activeOpacity={0.7}>
                                <Ionicons name="thumbs-up" size={26} color="#0F5468" />
                            </TouchableOpacity>
                        ) : (
                            <TouchableOpacity style={styles.sendBtn} onPress={() => handleSend(inputText)} activeOpacity={0.8}>
                                <LinearGradient
                                    colors={[COLORS.primary, COLORS.primaryDark]}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 1 }}
                                    style={styles.sendBtnGradient}
                                >
                                    <Ionicons name="send" size={17} color="#FFFFFF" />
                                </LinearGradient>
                            </TouchableOpacity>
                        )}
                    </View>
                </View>
            </KeyboardAvoidingView>

            {/* Modal: Thả Reaction */}
            <Modal visible={!!selectedMsgForReaction} transparent={true} animationType="fade" onRequestClose={() => setSelectedMsgForReaction(null)}>
                <TouchableOpacity style={styles.reactionOverlay} activeOpacity={1} onPress={() => setSelectedMsgForReaction(null)}>
                    <View style={styles.reactionCard}>
                        {/* Thanh Emoji */}
                        <View style={styles.emojiBar}>
                            {EMOJI_LIST.map((emoji) => (
                                <TouchableOpacity key={emoji} style={styles.emojiItem} onPress={() => selectedMsgForReaction && handleAddReaction(selectedMsgForReaction.id_tin_nhan, emoji)}>
                                    <Text style={{ fontSize: 28 }}>{emoji}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>

                        {/* Menu thao tác */}
                        <View style={styles.msgActionMenu}>
                            <TouchableOpacity
                                style={styles.msgActionRow}
                                onPress={() => {
                                    setReplyingTo(selectedMsgForReaction);
                                    setSelectedMsgForReaction(null);
                                }}
                            >
                                <Ionicons name="arrow-undo-outline" size={20} color="#10303C" />
                                <Text style={styles.msgActionText}>Trả lời tin nhắn</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.msgActionRow}
                                onPress={() => {
                                    Alert.alert("Đã sao chép", "Nội dung tin nhắn đã được lưu.");
                                    setSelectedMsgForReaction(null);
                                }}
                            >
                                <Ionicons name="copy-outline" size={20} color="#10303C" />
                                <Text style={styles.msgActionText}>Sao chép</Text>
                            </TouchableOpacity>

                            {selectedMsgForReaction?.id_nguoi_gui === currentUser.id_nguoi_dung && selectedMsgForReaction?.trang_thai !== "DA_THU_HOI" && (
                                <TouchableOpacity
                                    style={[styles.msgActionRow, { borderTopWidth: 1, borderTopColor: COLORS.borderLight }]}
                                    onPress={() => selectedMsgForReaction && handleRecall(selectedMsgForReaction.id_tin_nhan)}
                                >
                                    <Ionicons name="arrow-undo" size={20} color={COLORS.accentRed} />
                                    <Text style={[styles.msgActionText, { color: COLORS.accentRed }]}>Thu hồi tin nhắn</Text>
                                </TouchableOpacity>
                            )}
                        </View>
                    </View>
                </TouchableOpacity>
            </Modal>

            {/* Modal: Chi tiết đoạn chat (Messenger Info) */}
            <Modal visible={showInfoModal} animationType="slide" transparent={true} onRequestClose={() => setShowInfoModal(false)}>
                <View style={styles.infoModalOverlay}>
                    <View style={styles.infoModalContent}>
                        <View style={styles.dragHandle} />
                        <View style={styles.infoModalHeader}>
                            <TouchableOpacity onPress={() => setShowInfoModal(false)}>
                                <Ionicons name="close" size={26} color="#10303C" />
                            </TouchableOpacity>
                            <Text style={styles.infoModalTitle}>Chi tiết đoạn chat</Text>
                            <View style={{ width: 26 }} />
                        </View>

                        <ScrollView showsVerticalScrollIndicator={false}>
                            <View style={styles.infoProfile}>
                                <Image source={{ uri: displayAvatar }} style={styles.infoAvatar} />
                                <Text style={styles.infoName}>{displayName}</Text>
                                <Text style={styles.infoSub}>{isGroup ? "Nhóm rèn luyện VisionFit" : partner?.chuyen_mon || "Hội viên"}</Text>
                            </View>

                            <View style={styles.quickActions}>
                                <TouchableOpacity style={styles.quickActionBtn} onPress={() => Alert.alert("Hồ sơ", `Xem hồ sơ của ${displayName}`)}>
                                    <View style={styles.quickActionCircle}>
                                        <Ionicons name="person-outline" size={22} color="#0F5468" />
                                    </View>
                                    <Text style={styles.quickActionText}>Trang cá nhân</Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.quickActionBtn} onPress={() => Alert.alert("Thông báo", "Đã đổi trạng thái thông báo")}>
                                    <View style={styles.quickActionCircle}>
                                        <Ionicons name="notifications-outline" size={22} color="#0F5468" />
                                    </View>
                                    <Text style={styles.quickActionText}>Tắt thông báo</Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.quickActionBtn} onPress={() => Alert.alert("Tìm kiếm", "Tìm kiếm tin nhắn trong chat")}>
                                    <View style={styles.quickActionCircle}>
                                        <Ionicons name="search-outline" size={22} color="#0F5468" />
                                    </View>
                                    <Text style={styles.quickActionText}>Tìm kiếm</Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.quickActionBtn} onPress={() => Alert.alert("Chủ đề", "Đổi chủ đề màu sắc")}>
                                    <View style={styles.quickActionCircle}>
                                        <Ionicons name="color-palette-outline" size={22} color="#0F5468" />
                                    </View>
                                    <Text style={styles.quickActionText}>Chủ đề</Text>
                                </TouchableOpacity>
                            </View>

                            <View style={styles.infoSection}>
                                <Text style={styles.infoSectionTitle}>TÙY CHỈNH ĐOẠN CHAT</Text>
                                <TouchableOpacity style={styles.infoRow}>
                                    <Ionicons name="pencil-outline" size={20} color="#10303C" />
                                    <Text style={styles.infoRowText}>Đổi tên đoạn chat</Text>
                                    <Ionicons name="chevron-forward" size={18} color="#6F8F9C" />
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.infoRow}>
                                    <Ionicons name="images-outline" size={20} color="#10303C" />
                                    <Text style={styles.infoRowText}>File phương tiện, file và liên kết</Text>
                                    <Ionicons name="chevron-forward" size={18} color="#6F8F9C" />
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.infoRow}>
                                    <Ionicons name="fitness-outline" size={20} color="#10303C" />
                                    <Text style={styles.infoRowText}>Lịch sử buổi tập & Phân tích AI</Text>
                                    <Ionicons name="chevron-forward" size={18} color="#6F8F9C" />
                                </TouchableOpacity>
                            </View>

                            <View style={styles.infoSection}>
                                <Text style={styles.infoSectionTitle}>QUYỀN RIÊNG TƯ & HỖ TRỢ</Text>
                                <TouchableOpacity style={styles.infoRow}>
                                    <Ionicons name="shield-checkmark-outline" size={20} color="#10303C" />
                                    <Text style={styles.infoRowText}>Xác minh bảo mật đầu cuối</Text>
                                    <Ionicons name="chevron-forward" size={18} color="#6F8F9C" />
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.infoRow}>
                                    <Ionicons name="warning-outline" size={20} color={COLORS.accentRed} />
                                    <Text style={[styles.infoRowText, { color: COLORS.accentRed }]}>Báo cáo sự cố / PT</Text>
                                    <Ionicons name="chevron-forward" size={18} color="#6F8F9C" />
                                </TouchableOpacity>
                            </View>
                        </ScrollView>
                    </View>
                </View>
            </Modal>

            {/* Modal: Xem ảnh phóng to */}
            <Modal visible={!!previewImage} transparent={true} animationType="fade" onRequestClose={() => setPreviewImage(null)}>
                <View style={styles.fullImageOverlay}>
                    <TouchableOpacity style={styles.fullImageCloseBtn} onPress={() => setPreviewImage(null)}>
                        <Ionicons name="close" size={30} color="#FFFFFF" />
                    </TouchableOpacity>
                    {previewImage && <Image source={{ uri: previewImage }} style={styles.fullImage} resizeMode="contain" />}
                </View>
            </Modal>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.background,
    },
    headerWrap: {
        backgroundColor: COLORS.background,
    },
    header: {
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 12,
        paddingTop: 8,
        paddingBottom: 16,
        borderRadius: 28,
        marginHorizontal: 12,
        marginTop: 6,
        overflow: "hidden",
    },
    headerCircle: {
        position: "absolute",
        width: 180,
        height: 180,
        borderRadius: 90,
        backgroundColor: "rgba(255,255,255,0.07)",
        top: -90,
        right: -40,
    },
    headerBackBtn: {
        width: 38,
        height: 38,
        borderRadius: 13,
        backgroundColor: "rgba(255,255,255,0.15)",
        borderWidth: 1,
        borderColor: "rgba(255,255,255,0.2)",
        alignItems: "center",
        justifyContent: "center",
        marginRight: 10,
    },
    headerUserInfo: {
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
    },
    headerAvatarWrap: {
        position: "relative",
        marginRight: 10,
    },
    headerAvatar: {
        width: 42,
        height: 42,
        borderRadius: 21,
        borderWidth: 2,
        borderColor: "rgba(255,255,255,0.6)",
        backgroundColor: COLORS.primaryLight,
    },
    headerOnlineDot: {
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 12,
        height: 12,
        borderRadius: 6,
        backgroundColor: COLORS.accentGreen,
        borderWidth: 2,
        borderColor: COLORS.white,
    },
    headerName: {
        fontSize: 16,
        fontWeight: "800",
        color: COLORS.white,
    },
    headerStatus: {
        fontSize: 11.5,
        color: "rgba(255,255,255,0.8)",
    },
    headerPtTag: {
        backgroundColor: "rgba(255,255,255,0.2)",
        paddingHorizontal: 6,
        paddingVertical: 1,
        borderRadius: 5,
        marginLeft: 6,
    },
    headerPtTagText: {
        fontSize: 9,
        fontWeight: "800",
        color: COLORS.white,
    },
    headerActions: {
        flexDirection: "row",
        alignItems: "center",
    },
    headerActionBtn: {
        width: 34,
        height: 34,
        borderRadius: 17,
        backgroundColor: "rgba(255,255,255,0.15)",
        alignItems: "center",
        justifyContent: "center",
        marginLeft: 6,
    },
    chatBody: {
        flex: 1,
        backgroundColor: COLORS.background,
    },
    messagesList: {
        paddingHorizontal: 14,
        paddingTop: 18,
        paddingBottom: 16,
    },
    msgRow: {
        flexDirection: "row",
        marginBottom: 14,
        alignItems: "flex-end",
    },
    msgRowSender: {
        justifyContent: "flex-end",
    },
    msgRowReceiver: {
        justifyContent: "flex-start",
    },
    msgAvatar: {
        width: 30,
        height: 30,
        borderRadius: 15,
        marginRight: 8,
        marginBottom: 18,
        backgroundColor: COLORS.primaryLight,
    },
    msgBubbleWrap: {
        maxWidth: "76%",
    },
    bubble: {
        borderRadius: 18,
        paddingHorizontal: 14,
        paddingVertical: 10,
        ...SHADOWS.small,
    },
    bubbleSender: {
        backgroundColor: COLORS.primary,
        borderBottomRightRadius: 6,
    },
    bubbleReceiver: {
        backgroundColor: COLORS.white,
        borderWidth: 1,
        borderColor: COLORS.border,
        borderBottomLeftRadius: 6,
    },
    bubbleText: {
        fontSize: 14.5,
        lineHeight: 20,
    },
    bubbleTextSender: {
        color: "#FFFFFF",
    },
    bubbleTextReceiver: {
        color: COLORS.textPrimary,
    },
    bubbleRecalled: {
        backgroundColor: COLORS.borderLight,
        borderColor: COLORS.border,
        borderStyle: "dashed",
        borderWidth: 1,
    },
    recalledText: {
        fontSize: 13,
        fontStyle: "italic",
        color: COLORS.textMuted,
    },
    bubbleImage: {
        width: 220,
        height: 160,
        borderRadius: 14,
        marginBottom: 8,
    },
    workoutCard: {
        backgroundColor: COLORS.white,
        borderRadius: 16,
        padding: 12,
        marginBottom: 6,
        borderWidth: 1,
        borderColor: COLORS.border,
    },
    workoutIconWrap: {
        width: 34,
        height: 34,
        borderRadius: 11,
        backgroundColor: COLORS.primary,
        justifyContent: "center",
        alignItems: "center",
    },
    workoutTag: {
        fontSize: 10,
        fontWeight: "800",
        color: COLORS.primary,
        letterSpacing: 0.4,
    },
    workoutTitle: {
        fontSize: 13,
        fontWeight: "700",
        color: COLORS.textPrimary,
        marginTop: 2,
    },
    workoutDivider: {
        height: 1,
        backgroundColor: COLORS.borderLight,
        marginVertical: 10,
    },
    workoutDetailRow: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 4,
    },
    workoutDetailText: {
        fontSize: 12,
        color: COLORS.textSecondary,
        marginLeft: 6,
        fontWeight: "500",
    },
    confirmBtn: {
        backgroundColor: COLORS.primary,
        paddingVertical: 9,
        borderRadius: 12,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
    },
    confirmedBtn: {
        backgroundColor: COLORS.accentGreen,
    },
    confirmBtnText: {
        color: "#FFFFFF",
        fontSize: 12,
        fontWeight: "bold",
    },
    reactionBadge: {
        position: "absolute",
        bottom: -10,
        backgroundColor: COLORS.white,
        borderRadius: 12,
        paddingHorizontal: 6,
        paddingVertical: 2,
        flexDirection: "row",
        alignItems: "center",
        borderWidth: 1,
        borderColor: COLORS.border,
        ...SHADOWS.small,
    },
    timeRow: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 4,
        paddingHorizontal: 4,
    },
    timeText: {
        fontSize: 10.5,
        color: COLORS.textLight,
    },
    typingBubble: {
        flexDirection: "row",
        alignItems: "center",
        paddingVertical: 12,
        paddingHorizontal: 16,
        width: 64,
        justifyContent: "space-between",
    },
    typingDot: {
        width: 7,
        height: 7,
        borderRadius: 4,
        backgroundColor: COLORS.primary,
    },
    replyBox: {
        flexDirection: "row",
        padding: 8,
        borderRadius: 10,
        marginBottom: 4,
        backgroundColor: "rgba(15, 84, 104, 0.12)",
    },
    replyBoxSender: {
        backgroundColor: "rgba(15, 84, 104, 0.15)",
    },
    replyBoxReceiver: {
        backgroundColor: "rgba(113, 148, 154, 0.15)",
    },
    replyLine: {
        width: 3,
        backgroundColor: COLORS.primary,
        borderRadius: 2,
        marginRight: 6,
    },
    replyAuthor: {
        fontSize: 11,
        fontWeight: "700",
        color: COLORS.primaryDark,
    },
    replyText: {
        fontSize: 12,
        color: COLORS.textSecondary,
    },
    toolbar: {
        backgroundColor: COLORS.white,
        borderTopWidth: 1,
        borderTopColor: COLORS.border,
        paddingHorizontal: 10,
        paddingTop: 10,
        paddingBottom: Platform.OS === "ios" ? 24 : 10,
        borderTopLeftRadius: 22,
        borderTopRightRadius: 22,
        ...SHADOWS.card,
        shadowOffset: { width: 0, height: -3 },
    },
    replyBanner: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: COLORS.primarySoft,
        borderLeftWidth: 3,
        borderLeftColor: COLORS.primary,
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 12,
        marginBottom: 8,
    },
    replyBannerTitle: {
        fontSize: 12,
        color: COLORS.primaryDark,
    },
    replyBannerText: {
        fontSize: 12,
        color: COLORS.textSecondary,
        marginTop: 2,
    },
    attachMenu: {
        flexDirection: "row",
        justifyContent: "space-around",
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: COLORS.borderLight,
        marginBottom: 8,
    },
    attachItem: {
        alignItems: "center",
    },
    attachIconWrap: {
        width: 48,
        height: 48,
        borderRadius: 16,
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 6,
    },
    attachLabel: {
        fontSize: 11,
        fontWeight: "600",
        color: COLORS.textSecondary,
    },
    toolbarInputRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    toolIconBtn: {
        padding: 5,
        marginRight: 2,
    },
    inputBox: {
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: COLORS.background,
        borderRadius: 22,
        paddingHorizontal: 14,
        paddingVertical: Platform.OS === "ios" ? 9 : 4,
        minHeight: 42,
        marginHorizontal: 6,
        borderWidth: 1,
        borderColor: COLORS.border,
    },
    input: {
        flex: 1,
        fontSize: 14.5,
        color: COLORS.textPrimary,
        maxHeight: 100,
        padding: 0,
    },
    emojiBtn: {
        padding: 4,
        marginLeft: 6,
    },
    likeBtn: {
        padding: 6,
        marginLeft: 2,
    },
    sendBtn: {
        width: 42,
        height: 42,
        borderRadius: 21,
        marginLeft: 2,
        ...SHADOWS.glow,
    },
    sendBtnGradient: {
        width: 42,
        height: 42,
        borderRadius: 21,
        justifyContent: "center",
        alignItems: "center",
    },
    dragHandle: {
        alignSelf: "center",
        width: 40,
        height: 5,
        borderRadius: 3,
        backgroundColor: COLORS.border,
        marginBottom: 12,
    },
    reactionOverlay: {
        flex: 1,
        backgroundColor: "rgba(17, 52, 58, 0.45)",
        justifyContent: "center",
        alignItems: "center",
        paddingHorizontal: 24,
    },
    reactionCard: {
        width: "100%",
        alignItems: "center",
    },
    emojiBar: {
        flexDirection: "row",
        backgroundColor: COLORS.white,
        borderRadius: 30,
        paddingHorizontal: 14,
        paddingVertical: 8,
        marginBottom: 16,
        ...SHADOWS.card,
        shadowOpacity: 0.15,
        elevation: 6,
    },
    emojiItem: {
        paddingHorizontal: 8,
    },
    msgActionMenu: {
        width: "100%",
        backgroundColor: COLORS.white,
        borderRadius: 20,
        paddingVertical: 8,
        ...SHADOWS.card,
        shadowOpacity: 0.15,
        elevation: 6,
    },
    msgActionRow: {
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 18,
        paddingVertical: 14,
    },
    msgActionText: {
        fontSize: 15,
        fontWeight: "600",
        color: COLORS.textPrimary,
        marginLeft: 14,
    },
    infoModalOverlay: {
        flex: 1,
        backgroundColor: "rgba(17, 52, 58, 0.45)",
        justifyContent: "flex-end",
    },
    infoModalContent: {
        backgroundColor: COLORS.white,
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        paddingHorizontal: 20,
        paddingTop: 10,
        paddingBottom: 36,
        maxHeight: "85%",
    },
    infoModalHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 16,
    },
    infoModalTitle: {
        fontSize: 17,
        fontWeight: "800",
        color: COLORS.textPrimary,
    },
    infoProfile: {
        alignItems: "center",
        marginVertical: 12,
    },
    infoAvatar: {
        width: 84,
        height: 84,
        borderRadius: 42,
        borderWidth: 3,
        borderColor: COLORS.primary,
        marginBottom: 10,
        backgroundColor: COLORS.primaryLight,
    },
    infoName: {
        fontSize: 19,
        fontWeight: "800",
        color: COLORS.textPrimary,
    },
    infoSub: {
        fontSize: 13,
        color: COLORS.textMuted,
        marginTop: 4,
        textAlign: "center",
    },
    quickActions: {
        flexDirection: "row",
        justifyContent: "space-around",
        marginVertical: 18,
    },
    quickActionBtn: {
        alignItems: "center",
        width: 76,
    },
    quickActionCircle: {
        width: 48,
        height: 48,
        borderRadius: 16,
        backgroundColor: COLORS.primaryLight,
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 6,
    },
    quickActionText: {
        fontSize: 11,
        fontWeight: "600",
        color: COLORS.textSecondary,
        textAlign: "center",
    },
    infoSection: {
        marginTop: 16,
    },
    infoSectionTitle: {
        fontSize: 11,
        fontWeight: "800",
        color: COLORS.textMuted,
        letterSpacing: 0.8,
        marginBottom: 8,
    },
    infoRow: {
        flexDirection: "row",
        alignItems: "center",
        paddingVertical: 13,
        borderBottomWidth: 1,
        borderBottomColor: COLORS.borderLight,
    },
    infoRowText: {
        flex: 1,
        fontSize: 14.5,
        fontWeight: "500",
        color: COLORS.textPrimary,
        marginLeft: 12,
    },
    fullImageOverlay: {
        flex: 1,
        backgroundColor: "#000000",
        justifyContent: "center",
        alignItems: "center",
    },
    fullImageCloseBtn: {
        position: "absolute",
        top: 50,
        right: 20,
        zIndex: 10,
    },
    fullImage: {
        width: "100%",
        height: "80%",
    },
});

export default ChatRoom;
