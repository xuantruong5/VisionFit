<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('khau_phan_an', function (Blueprint $table) {
            $table->id();  //id_khau_phan_an;
            $table->unsignedBigInteger('id_ke_hoach_an')->nullable();
             $table->unsignedBigInteger('id_muc_tieu_dinh_duong');
            $table->unsignedBigInteger('id_mon_an');
            $table->unsignedInteger('ngay_thu')->default(1);
            $table->date('ngay_an')->nullable();
            $table->time('gio_an')->nullable()->comment('Giờ ăn');
            $table->string('bua_an', 30); // SANG, PHU_SANG, TRUA, PHU_TRUA, TOI, PHU_TOI (6 bữa )
            // Số lượng khẩu phần
            $table->decimal('so_luong', 8, 2)->default(1)->comment('Số khẩu phần');
            // $table->decimal('tong_calo', 10, 2)->default(0)->comment('Tổng năng lượng (kcal)');
            $table->string('ghi_chu')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('khau_phan_an');
    }
};
